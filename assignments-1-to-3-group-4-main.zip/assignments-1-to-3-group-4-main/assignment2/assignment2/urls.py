"""assignment2 URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, re_path # Added re_path
from assignment2_app import views # Added import views

urlpatterns = [
    path('admin/', admin.site.urls),
    re_path(r'^$', views.index, name='home'),
    # User paths
    re_path(r'^users/?$', views.users, name='users'),
    re_path(r'^add_user/?$', views.add_user, name='add_user'),
    re_path(r'^add_user_done/?$', views.add_user_done),
    re_path(r'^edit_user/(?P<key>\d+)?/?$', views.modify_user, name='edit_user'),
    # Developer paths
    re_path(r'^developers/?$', views.developers, name='developers'),
    re_path(r'^add_developer/?$', views.add_developer, name='add_developer'),
    re_path(r'^add_developer_done/?$', views.add_developer_done),
    re_path(r'^edit_developer/(?P<key>\d+)?/?$', views.modify_developer, name='edit_developer'),
    # Publisher paths
    re_path(r'^publishers/?$', views.publishers, name='publishers'),
    re_path(r'^add_publisher/?$', views.add_publisher, name='add_publisher'),
    re_path(r'^add_publisher_done/?$', views.add_publisher_done),
    re_path(r'^edit_publisher/(?P<key>\d+)?/?$', views.modify_publisher, name='edit_publisher'),
    # Game paths
    re_path(r'^games/?$', views.games, name='games'),
    re_path(r'^add_game/?$', views.add_game, name='add_game'),
    re_path(r'^add_game_done/?$', views.add_game_done),
    re_path(r'^edit_game/(?P<key>\d+)?/?$', views.modify_game, name='edit_game'),
]

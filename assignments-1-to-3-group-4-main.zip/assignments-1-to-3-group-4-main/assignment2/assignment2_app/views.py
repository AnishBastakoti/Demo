from django.shortcuts import render
from assignment2_app.models import User, Game, Developer, Publisher
from assignment2_app.forms import UserForm, DeveloperForm, PublisherForm, GameForm
from django.http import HttpResponseRedirect
from django.urls import reverse

import datetime

# Create your views here.
# Home page
def index(request):
    return render(request, 'assignment2_app/index.html')

# universal edit function for all functions bellow
def edit_this(form):
    form.save()
    return None

# universal delete function for all functions bellow
def delete_this(var):
    var.delete()
    return None

############# START of developer functions #############
# lists out devs for developers.html
def developers(request):

    devlist = Developer.objects.all()

    page_data = {
        'devs': devlist,
    }

    return render(request, 'assignment2_app/developers.html', page_data)

# Add developer
def add_developer(request):

        page_data = {
            'myform': DeveloperForm(),
            'page': 'developer',
        }

        return render(request, 'assignment2_app/add.html', page_data)

# Saves new Developer or returns errors
def add_developer_done(request):
    if request.method != 'POST': # e.g: If user types in url /add_developer_done
        return HttpResponseRedirect('/add_developer/')
    else:
        page_data = {}
        form = DeveloperForm(request.POST) # puts the info, the user has input, into DeveloperForm.
        if form.is_valid():
            form.save()
            return HttpResponseRedirect(reverse('developers'))
        else:
            page_data = {'val_errors': form.errors, }
    return render(request, 'assignment2_app/error.html', page_data)

# edit or delete Developer
def modify_developer(request, key=1):
    var = Developer.objects.get(id=int(key)) # gets id of requested Developer and saves it in 'var'

    page_data = None

    if request.method == 'POST':
        if 'edit' in request.POST: # if name="edit" in edit.html
            form = DeveloperForm(request.POST, instance=var) # saves changes, made by user, in variable 'form'
            if form.is_valid():
                edit_this(form)
            else:
                page_data = {
                'val_errors': form.errors,
                }
                return render(request, 'assignment2_app/error.html', page_data)
        elif 'delete' in request.POST:
            delete_this(var)
        return HttpResponseRedirect(reverse('developers'))
    else:
        form = DeveloperForm(instance=var) # will always be dev with id=1
        path = request.path # save the url in variable 'path'
        page_data = {'myform': form, 'page':path[6:15],} # path[6:15] is just the text 'developer'

    return render(request, 'assignment2_app/edit.html', page_data)
# END of developer functions

############# START of Publisher functions #############
# Grabs all Publishers
def publishers(request):

    publist = Publisher.objects.all()

    page_data = {
        'pubs': publist
    }

    return render(request, 'assignment2_app/publishers.html', page_data)

# Add publisher
def add_publisher(request):

        page_data = {
            'myform': PublisherForm(),
            'page': 'publisher',
        }

        return render(request, 'assignment2_app/add.html', page_data)

# Saves new publisher, handles errors
def add_publisher_done(request):
    if request.method != 'POST':
        return HttpResponseRedirect('/add_publisher/')
    else:
        page_data = {}
        form = PublisherForm(request.POST) # puts the info, the user has input, into PublisherForm.
        if form.is_valid():
            form.save()
            return HttpResponseRedirect(reverse('publishers'))
        else:
            page_data = {'val_errors': form.errors, }
    return render(request, 'assignment2_app/error.html', page_data)

# edit or delete publisher
def modify_publisher(request, key=1):
    var = Publisher.objects.get(id=int(key))

    page_data = None

    if request.method == 'POST':
        if 'edit' in request.POST:
            form = PublisherForm(request.POST, instance=var)
            if form.is_valid():
                edit_this(form)
            else:
                page_data = {
                'val_errors': form.errors,
                }
                return render(request, 'assignment2_app/error.html', page_data)
        elif 'delete' in request.POST:
            delete_this(var)
        return HttpResponseRedirect(reverse('publishers'))
    else:
        form = PublisherForm(instance=var)
        path = request.path
        page_data = {'myform': form, 'page':path[6:15]}

    return render(request, 'assignment2_app/edit.html', page_data)
# END of publisher functions



############# START of user functions #############
def users(request):

    userlist = User.objects.all()
    page_data = {
        'users': userlist
    }

    return render(request, 'assignment2_app/users.html', page_data)

# Add user
def add_user(request):

    page_data = {
        'myform': UserForm(),
        'page': 'user',
    }

    return render(request, 'assignment2_app/add.html', page_data)

def add_user_done(request):
    if request.method != 'POST':
        return HttpResponseRedirect('/add_user/')
    else:
        # If got time: should add validation; check if username already taken?
        page_data = {}
        form = UserForm(request.POST) # puts the info, the user has input, into UserForm.
        if form.is_valid():
            form.save()
            return HttpResponseRedirect(reverse('users'))
        else:
            page_data = {'val_errors': form.errors, }
    return render(request, 'assignment2_app/error.html', page_data)

# edit or delete users
def modify_user(request, key=1):

    var = User.objects.get(id=int(key))
    page_data = None

    if request.method == 'POST':
        if 'edit' in request.POST:
            form = UserForm(request.POST, instance=var)
            if form.is_valid():
                edit_this(form)
            else:
                page_data = {
                'val_errors': form.errors,
                }
                return render(request, 'assignment2_app/error.html', page_data)
        elif 'delete' in request.POST:
            delete_this(var)
        return HttpResponseRedirect(reverse('users'))
    else:
        form = UserForm(instance=var)
        path = request.path
        page_data = {'myform': form, 'page':path[6:10]}

    return render(request, 'assignment2_app/edit.html', page_data)
# END of User functions


############# START of game functions #############
def games(request):

    gamelist = Game.objects.all()
    page_data = {
        'games': gamelist,
    }
    return render(request, 'assignment2_app/games.html', page_data)

# Add Game
def add_game(request):

    page_data = {
        'myform': GameForm(),
        'page':'game',
    }
    return render(request, 'assignment2_app/add.html', page_data)

# Saves game data.
def add_game_done(request):

    if request.method != 'POST': # if user manually inputs url
        return HttpResponseRedirect('/add_game/')
    else:
        page_data = {}
        form = GameForm(request.POST) # puts the info, the user has input, into GameForm.
        if form.is_valid():
            form.save()
            return HttpResponseRedirect(reverse('games'))
        else:
            page_data = {
            'val_errors': form.errors,
            }
    return render(request, 'assignment2_app/error.html', page_data)

# Edit or delete games
def modify_game(request, key=72850): # make default key a valid steam_app_id

    var = Game.objects.get(steam_app_id=int(key))
    page_data = None

    if request.method == 'POST':
        if 'edit' in request.POST:
            form = GameForm(request.POST, instance=var) # instance = this specific game, due to var = it's id
            if form.is_valid():
                edit_this(form)
            else:
                page_data = {
                'val_errors': form.errors,
                }
                return render(request, 'assignment2_app/error.html', page_data)
        elif 'delete' in request.POST:
            delete_this(var)
        return HttpResponseRedirect(reverse('games'))
    else:
        form = GameForm(instance=var)
        path = request.path
        page_data = {
        'myform': form,
        'page':path[6:10]
        }
    return render(request, 'assignment2_app/edit.html', page_data)
# END of game functions

# Need to figure out how to simplify the modify functions.

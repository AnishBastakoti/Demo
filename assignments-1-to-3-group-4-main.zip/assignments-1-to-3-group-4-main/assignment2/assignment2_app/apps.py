from django.apps import AppConfig


class Assignment2AppConfig(AppConfig):
    name = 'assignment2_app'

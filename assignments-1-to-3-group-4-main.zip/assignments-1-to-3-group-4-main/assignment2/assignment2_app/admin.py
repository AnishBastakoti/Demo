from django.contrib import admin
from assignment2_app.models import User, Developer, Publisher, Game

# Register your models here.
myModels = [User, Developer, Publisher, Game]
admin.site.register(myModels)

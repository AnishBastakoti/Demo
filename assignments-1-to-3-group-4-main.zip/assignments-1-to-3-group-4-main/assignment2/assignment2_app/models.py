from django.db import models

# Create your models here.
class Developer(models.Model):
    name = models.CharField(max_length=30)
    year_founded = models.IntegerField() # max_length is ignored when using an Interger field
    city = models.CharField(max_length=60)
    state = models.CharField(max_length=30)
    country = models.CharField(max_length=50)
    website = models.URLField()

    def __str__(self):
        return self.name

class Publisher(models.Model):
    name = models.CharField(max_length=30)
    year_founded = models.IntegerField()
    city = models.CharField(max_length=60)
    state = models.CharField(max_length=30)
    country = models.CharField(max_length=50)
    website = models.URLField()

    def __str__(self):
        return self.name


class User(models.Model):
    username = models.CharField(max_length=30)
    password = models.CharField(max_length=30)
    email = models.EmailField()

    def __str__(self):
        return self.username

class Game(models.Model):
    steam_app_id = models.IntegerField(primary_key=True)
    title = models.CharField(max_length=50)
    users = models.ManyToManyField(User)
    developer = models.ForeignKey(Developer, on_delete=models.CASCADE)
    publisher = models.ForeignKey(Publisher, on_delete=models.CASCADE)
    release_date = models.DateField()

    def __str__(self):
        return self.title

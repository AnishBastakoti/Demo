from django import forms
from .models import *

class UserForm(forms.ModelForm):
    class Meta:
        model = User

        exclude = []

class DeveloperForm(forms.ModelForm):
    class Meta:
        model = Developer

        exclude = []

        labels = {
            'state': 'State/Province'
        }

class PublisherForm(forms.ModelForm):
    class Meta:
        model = Publisher

        exclude = []

        labels = {
            'state': 'State/Province'
        }

class GameForm(forms.ModelForm):
    class Meta:
        model = Game

        exclude = []

        labels = {
            'users': 'Users (ctrl-click for multiple)',
            'release_date': 'Release date (year-month-day)',
        }

"""website URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, re_path # Added re_path
from website_app import views # Import views


urlpatterns = [
    path('admin/', admin.site.urls),
    re_path(r'^$', views.home, name='home'),
    re_path(r'^catalogue/?$', views.list, name='list'),
    re_path(r'^information/$', views.detail, name='detail'), # Fail-safe; if user navigates to information url without number (album_id).
    re_path(r'^information/(?P<album_id>[1-7]{1})/?$', views.detail, name='detail'),
    re_path(r'^model/?$', views.model, name='model'),

]

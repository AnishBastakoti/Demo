class Album:
    """Stores details of an album."""
    def __init__(self, id, genre, artist, title, release_date, description):
        self.id = id
        self.genre = genre
        self.artist = artist
        self.title = title
        self.release_date = release_date
        self.description = description

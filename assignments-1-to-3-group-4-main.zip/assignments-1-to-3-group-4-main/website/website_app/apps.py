from django.apps import AppConfig


class WebsiteAppConfig(AppConfig):
    name = 'website_app'

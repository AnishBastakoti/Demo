from django.shortcuts import render
from website_app.album import Album # Gives access to Album class

# Create your views here.
def home(request):
    context_data= {
    	'name1': "Nathan Knopfler",
    	'id': "S310478",

        'name2': "Anish Bastakoti",
    	'id1': "S308822",

        'name3': "Ittehad Ibne Chowdhury",
    	'id2': "S325700",

        'name4': "Rakibul",
    	'id3': "S327368",
    }
    return render(request, 'website_app/home.html', context_data)

def list(request):
    context_data = {
        'album_list': create_album()
    }
    return render(request, 'website_app/list.html', context_data)


def create_album():
    main_list = []
    main_list.append(Album(1, 'Progressive Metal', 'Tool', 'Lateralus', 'May 15th, 2001', 'Buckle up! This ablum will take you places.'))
    main_list.append(Album(2, 'Math rock', 'Chon', 'Grow', 'March 24th, 2015', 'Lets get funky... but in a technical way.'))
    main_list.append(Album(3, 'Folk rock', 'Emma Ruth Rundle', 'On Dark Horses', 'September 14, 2018', 'Like a train heading towards a storm.'))
    main_list.append(Album(4, 'Dance/Electronic', 'Goreshit', 'My Love Feels All Wrong. Digipak', 'April 27th, 2015', 'Get your dance shoes, and your favourite body pillow!'))
    main_list.append(Album(5, 'Pop/Rock', 'Taylor Swift', 'Reputation', 'November 10th, 2016', 'Reputation is the sixth studio album by American singer-songwriter Taylor Swift. It was released by Big Machine Records.Following the release of her fifth studio album, 1989, Swift was involved in disputes with several high-profile celebrities, which became a subject of widespread tabloid scrutiny. She hence secluded herself from the press and social media, where she had maintained an active presence with a large following. During this period, Swift created Reputation with producers Jack Antonoff, Max Martin, and Shellback, as an effort to revamp her state of mind. This album contains 15 tracks, and has won several music awards. Reputation sold over 1 million digital copies in the first week of the release making it the biggest album sales of that year.'))
    main_list.append(Album(6, 'Rock', 'Linkin Park', 'Hybrid Theory', 'October 24th, 2000', 'Hybrid Theory is the debut studio album by American rock band Linkin Park, released through Warner Bros Records. Recorded at NRG Recordings in North Hollywood, California, and produced by Don Gilmore, the album lyrical themes deal with problems lead vocalist Chester Bennington experienced during his adolescence, including drug abuse and the constant fighting and divorce. The album contains 12 tracks however, in Japanese edition there were 3 more tracks, in iTunes delux edition there were 4 more tracks, This album chart no 1 and 2 in lot of countries. Sadely Chester Bennington commited sucide on July 20, 2017, Palos Verdes Estates, California, U.S.'))
    main_list.append(Album(7, 'Qwwali', 'Nusrat Fateh Ali Khan', 'Mere Rashke Qamar', 'October 2nd, 1988', '"Mere Rashke Qamar" is a ghazal-qawwali written by Urdu poet Fana Buland Shehri and composed by Nusrat Fateh Ali Khan. It was first performed in 1988 by Khan, and popularized by him and his nephew Rahat Fateh Ali Khan several times in different concerts.'))

    return main_list

def detail(request, album_id='1'): #album_id = 1; incase user doesn't specify a number in the url

        id = int(album_id)
        album_list = create_album()

        album_number = None
        for item in album_list:
            if id == item.id:
                album_number = item

        context_data = {
            'album': album_number
        }

        return render(request, 'website_app/detail.html', context_data)

def model(request):
        return render(request, 'website_app/model.html')
